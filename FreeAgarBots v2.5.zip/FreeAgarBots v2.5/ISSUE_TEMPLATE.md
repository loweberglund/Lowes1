Please do not ask for proxies
Please do not talk about cheating on public servers.